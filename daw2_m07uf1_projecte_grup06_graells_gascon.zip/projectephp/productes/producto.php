<?php

class zapatillas {
	protected $id;
	protected $marca;
	protected $modelo;
	protected $precio;

	public function __construct(
		int $id,
		string $marca,
		string $modelo,
		float $precio
	) {
		$this->id = $id;
		$this->marca = $marca;
		$this->modelo = $modelo;
		$this->precio = $precio;
	}

	public function id(): int{
		return $this->id;
	}

	public function marca(): string{
		return $this->marca;
	}

	public function setMarca($n){
		$this->marca = $n;
	}
	public function modelo(): string{
		return $this->modelo;
	}
	
	public function setModelo($d){
		$this->modelo = $d;
	}
		public function precio(): float{
		return $this->precio;
	}
	
	public function setPrecio($p){
		$this->precio = $p;
	}

	public function __toString(){
		return $this->id ."-".$this->name."-".$this->price."-".$this->description."\n";
	}
}
?>


