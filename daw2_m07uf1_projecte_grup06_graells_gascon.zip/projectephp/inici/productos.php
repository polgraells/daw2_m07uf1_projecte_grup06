<?php
class producte{
	
	private $id;
	private $marca;
	private $precio;
	
	public function __construct($id,$marca,$precio){	
			$this->id = $id;
			$this->marca = $marca;
			$this->precio = $precio;
		}
		
	public function __get($prop){
			if(property_exists($this,$prop)){
				return $this->$prop;
			}
			else{
				return -1;
			}		
		}
		
	public function __set($prop,$valor){
			if(property_exists($this,$prop)){
				$this->$prop=$valor;
			}
		}
	
	public function escriu($arxiu,$text){
		fwrite($arxiu,$text);
		fwrite($arxiu,"\n");
		fclose($arxiu);
	}
}	


$identificador=$_POST['id'];
$marca=$_POST['marca'];
$model=$_POST['model'];
$preu=$_POST['preu'];

$zapatillas=new producte($identificador,  $marca, $model, $preu);

$general="/var/www/html/projectephp/inici/productes";								
$fp=fopen($general,"a") or die ("No s'ha pogut afegir al fitxer");
$text=$zapatillas->id."-".$zapatillas->marca."-".$zapatillas->model."-".$zapatillas->preu."€";															
$zapatillas->escriu($fp,$text);
fclose($fp);


$filename="/var/www/html/projectephp/inici/dirproductes/".$identificador;			
$fitxer=fopen($filename,"w") or die ("No s'ha pogut crear");
$texte=$zapatillas->id."-".$zapatillas->marca."-".$zapatillas->model."-".$zapatillas->preu."€";		
$zapatillas->escriu($fitxer,$texte);
fclose($filename);


header('Location: http://localhost/projectephp/inici/manteniment_cataleg.php');

?>	
