<?php
	session_start();
?>
<html>
	<head>
		<title>
			PRODUCTOS
		</title>
		<link rel="stylesheet" type="text/css" href="../css/productes.css"/>
		<script language="javascript" src="EsbPro.js"></script>
	</head>
	<body>
        <div class="encabezado">
          <ul>
            <li class="productos"><a href="productosadmin.php"> GESTION PRODUCTOS</a></li>
            <li class="usuario"><a href="usuaris.php">USUARIS</a></li>
            <li class="session"><a href="logout.php">LOGOUT</a></li>
            <li class="imagen"><a href="comandes.php"><img src="../imatge/carrito.jpeg"></a></li>
          </ul>
        </div>
      </header>
      </div>
      <br>
      <br>
      <br>
      <br>
      <br>
      <br>
      <br>
			<h2 class="titol">PRODUCTES CATALEG</h2>
			
			<div class="llista1">
			<h3>AFEGIR PRODUCTE</h3>
				<form action="http://localhost/projectephp/inici/productos.php" method="POST">
					Marca: <select name="seccio">
								<option value="adidas">Adidas</option>
								<option value="Nike">Nike</option>
								<option value="Jordan">Jordan</option>
							</select>
					Model <input type="text" name="model"><br>
					Preu <input type="text" name="preu"><br>
					Identificador <input type="text" name="id"><br>
					<input type="submit" value="Envia"/>
				</form>
			</div>
			
			<br><br>
			
			<div class="llista2">
			<h3>CATALEG DE PRODUCTES </h3>
			<p><u><b>ADIDAS</b></u></p>
			<table>
				<tr id="cap">
					<td>IDENTIFICADOR</td>
					<td>MODEL</td>
					<td>PREU</td>
				</tr>
			<?php
				$fitxer_productes="/var/www/html/projectephp/inici/productes";
				$fp=fopen($fitxer_productes,"r") or die ("No s'ha pogut validar l'usuari");
				if ($fp) {
					$mida_fitxer=filesize($fitxer_productes);	
					$productes = explode(PHP_EOL, fread($fp,$mida_fitxer));
				}
				foreach ($productes as $producte) {
				$separar = explode("-",$producte);
					if ($separar[1] == "Adidas"){
						$id = $separar[0];
						$model = $separar[2];
						$preu = $separar[3];

			?>
				<tr>
					<td><?php echo $id; ?></td>
					<td><?php echo $model; ?></td>
					<td><?php echo $preu; ?></td>

				</tr>
					
			<?php
					}
				}
			?>
			</table>
			
			<p><u><b>NIKE</b></u></p>
			<table>
				<tr id="cap">
					<td>IDENTIFICADOR</td>
					<td>MODEL</td>
					<td>PREU</td>

				</tr>
			<?php
				$fitxer_productes="/var/www/html/projectephp/inici/productes";
				$fp=fopen($fitxer_productes,"r") or die ("No s'ha pogut validar l'usuari");
				if ($fp) {
					$mida_fitxer=filesize($fitxer_productes);	
					$productes = explode(PHP_EOL, fread($fp,$mida_fitxer));
				}
				foreach ($productes as $producte) {
				$separar = explode("-",$producte);
					if ($separar[1] == "Nike"){
						$id = $separar[0];
						$model = $separar[3];
						$preu = $separar[4];

			?>
				<tr>
					<td><?php echo $id; ?></td>
					<td><?php echo $model; ?></td>
					<td><?php echo $preu; ?></td>

				</tr>
					
			<?php
					}
				}
			?>
			</table>
			<p><u><b>JORDAN</b></u></p>
			<table>
				<tr id="cap">
					<td>IDENTIFICADOR</td>
					<td>MODEL</td>
					<td>PREU</td>

				</tr>
			<?php
				$fitxer_productes="/var/www/html/projectephp/inici/productes";
				$fp=fopen($fitxer_productes,"r") or die ("No s'ha pogut validar l'usuari");
				if ($fp) {
					$mida_fitxer=filesize($fitxer_productes);	
					$productes = explode(PHP_EOL, fread($fp,$mida_fitxer));
				}
				foreach ($productes as $producte) {
				$separar = explode("-",$producte);
					if ($separar[1] == "JORDAN"){
						$id = $separar[0];
						$model = $separar[3];
						$preu = $separar[4];

			?>
				<tr>
					<td><?php echo $id; ?></td>
					<td><?php echo $model; ?></td>
					<td><?php echo $preu; ?></td>

				</tr>
					
			<?php
					}
				}
			?>
			</table>
			</div>
			
			<br><br>
			
			<div class="llista3">			
			<h3>ELS PRODUCTES DISPONIBLES</h3>
			<table>
				<tr id="cap">
					<td>IDENTIFICADOR</td>

				</tr>
			<?php
				$productes="/var/www/html/projectephp/inici/dirproductes";
				$llista = scandir($productes);
				foreach($llista as $producte){
	

			?>
				<tr>
					<td><?php echo $producte; ?></td>
				</tr>
					
			<?php
				}
			?>
			</table>
			</div>
			<br><br>
			
			<div class="llista4">			
			<h3>MODIFICAR PRODUCTES</h3>
			<form action="http://localhost/projectephp/inici/modificarproducte.php" method="POST">
				Producte a modificar <select name="producte">
				<?php
				$productes="/var/www/html/projectephp/inici/dirproductes";
				$llista = scandir($productes);
				foreach($llista as $producte){
	

				?>
					<option><?php echo $producte; ?></option>					
				<?php
					}
				?>
				</select>
				Seccio: <select name="seccio">
							<option value="Adidas">Adidas</option>
							<option value="Nike">Nike</option>
							<option value="Jordan">Jordan</option>
						</select>
				Model <input type="text" name="model"><br>
				Preu <input type="text" name="preu"><br>
				<input type="submit" value="Envia"/>
			</form>
			</div>
			<br><br>	
			
			<div class="llista5">			
			<h3>DELETE PRODUCT</h3>
				<form id="frmEsbPro">
					<table>
						<tr>
							<td>Identificador de producte:</td>
							<td><select name="nomPro" id="nomPro">
							<?php
							$productes="/var/www/html/projectephp/inici/dirproductes";
							$llista = scandir($productes);
							foreach($llista as $producte){
			
							?>
								<option><?php echo $producte; ?></option>					
							<?php
								}
							?>
							</select></td>
						</tr>
					</table>
					<input type="button" name="bEsbPro" id="bEsbPro" value="Esborra producte" onclick="esbProducte();">
					<input type="button" name="bNet" id="bNet" value="Neteja formulari" onclick="netForm();">
				</form>
			</div>
		</body>
</html>
