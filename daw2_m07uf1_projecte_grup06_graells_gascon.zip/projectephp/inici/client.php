<?php
	$fitxer_usuaris="/var/www/html/projectephp/inici/usuaris";
	$fp=fopen($fitxer_usuaris,"r") or die ("No s'ha pogut validar l'usuari");
	if ($fp) {
		$mida_fitxer=filesize($fitxer_usuaris);	
		$usuaris = explode(PHP_EOL, fread($fp,$mida_fitxer));
    }
   	foreach ($usuaris as $usuari) {
		$logpwd = explode(":",$usuari);
		if (($_POST['usuari'] == $logpwd[0]) && ($_POST['ctsnya'] == $logpwd[1])){
			fclose($fitxer);
			session_name($_POST["usuari"]);
			session_start();
			break;
		}
	}
?>
	<html>
		<head>
			<meta htpp.equiv="Content-Type" content="text/html; charset=utf-8"/>
			<link href="../css/client.css" rel="stylesheet" type="text/css">
			<FONT FACE="">
				<TITLE>Projecte M07 - UF1</TITLE>
		</head>
		<body>
		<div class="cabezado">
			<form action="http://localhost/projectephp/inici/destrueix.php" method="POST">
				<a href=destrueix.php><img src="../imatge/logout.png"></a>
			</form>
	<body>
        <div class="encabezado">
          <ul>
            <li class="home"><a href="productosadmin.php"> GESTION PRODUCTOS</a></li>
            <li class="Serveis"><a href="usuaris.php">USUARIS</a></li>
            <li class="contact"><a href="logout.php">LOGOUT</a></li>
            <li class="contact"><a href="comandes.php"><img src="../imatge/carrito.jpeg"></a></li>
          </ul>
        </div>
         <div class="imagen2">
      <img src="../imatge/bambas6.jpg">
      </div>
		</body>
	</html>
