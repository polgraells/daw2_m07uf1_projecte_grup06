<?php
	session_start();	
?>
<html>
	<head>
		<title>
			COMANDES
		</title>
		<link rel="stylesheet" type="text/css" href="../css/carrito.css"/>
	</head>
	<header>
		<body>
        <div class="encabezado">
          <ul>
            <li class="home"><a href="productosadmin.php"> GESTION PRODUCTOS</a></li>
            <li class="Serveis"><a href="comandes.php">COMANDES</a></li>
            <li class="contact"><a href="usuaris.php">USUARIS</a></li>
            <li class="contact"><a href="logout.php">LOGOUT</a></li>
          </ul>
        </div>
      </header>
      <br>
      <br>
      <br>
      <br>
      <br>
      <br>

			<div class="llista">
			<h3>CREAR COMANDA</h3>
				<form action="http://localhost/projectephp/inici/clasecomanda.php" method="POST">
				Codi del producte: <select name="producte">
					
					<?php
					$productes="/var/www/html/projectephp/inici/dirproductes";		
					$llista = scandir($productes);
					foreach($llista as $producte){
		

					?>
						<option><?php echo $producte; ?></option>					
					<?php
						}
					?>

					</select>
					Cantitat <input type="text" name="cantitat">
					<input type="submit" value="Envia"/>
				</form>
			</div>
			
			<br><br>
			
			<div class="llista1">
			<h3>LES MEVES COMANDES</h3>
				<table>
				<tr id="cap">
					<td>IDENTIFICADOR</td>
					<td>PRODUCTE</td>
					<td>CANTITAT</td>

				</tr>
			<?php
				$fitxer_comandes="/var/www/html/projectephp/inici/comandes";
				$fp=fopen($fitxer_comandes,"r") or die ("No s'ha pogut validar l'usuari");
				if ($fp) {
					$mida_fitxer=filesize($fitxer_comandes);	
					$comandes = explode(PHP_EOL, fread($fp,$mida_fitxer));
				}
				foreach ($comandes as $comanda) {
				$separar = explode("-",$comanda);
				$ncomanda = explode(".",$comanda);

					if ($ncomanda[0] == $_SESSION['id']){				
						$id = $separar[0];
						$producte = $separar[1];
						$cantitat = $separar[2];

			?>
				<tr>
					<td><?php echo $id; ?></td>
					<td><?php echo $producte; ?></td>
					<td><?php echo $cantitat; ?></td>

				</tr>
					
			<?php
					}
				}
			?>
			</table>
			</div>
			
			<br><br>	
			
		</body>
</html>
