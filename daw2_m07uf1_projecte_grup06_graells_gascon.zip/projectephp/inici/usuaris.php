<?php

	session_start();
?>
<html>
	<head>
		<title>
			GESTIO USUARIS
		</title>
		<link rel="stylesheet" type="text/css" href="../css/usuari.css"/>
		<script language="javascript" src="EsbUsr.js"></script>
	</head>
		<body>
        <div class="encabezado">
          <ul>
            <li class="home"><a href="productosadmin.php"> GESTION PRODUCTOS</a></li>
            <li class="Serveis"><a href="usuaris.php">USUARIS</a></li>
            <li class="contact"><a href="logout.php">LOGOUT</a></li>
            <li class="contact"><a href="comandes.php"><img src="../imatge/carrito.jpeg"></a></li>
          </ul>
        </div>
			<br>
			<br>
			<br>
			<br>
			<br>
			<br>
			<div class="llista1">
			<h3>MODIFICACIONS I USUARIS</h3>
			<table>
				<tr id="cap">
					<td>ID</td>
					<td>NOM</td>
					<td>USUARI</td>

				</tr>
			<?php
				$fitxer_usuaris="/var/www/html/projectephp/inici/usuaris";
				$fp=fopen($fitxer_usuaris,"r") or die ("No s'ha pogut validar l'usuari");
				if ($fp) {
					$mida_fitxer=filesize($fitxer_usuaris);	
					$usuaris = explode(PHP_EOL, fread($fp,$mida_fitxer));
				}
				foreach ($usuaris as $usuari) {
					$logpwd = explode(":",$usuari);
					$id = $logpwd[7];
					$nom = $logpwd[2];
					$usuari = $logpwd[0];

			?>
				<tr>
					<td><?php echo $id; ?></td>
					<td><?php echo $nom; ?></td>
					<td><?php echo $usuari; ?></td>

				</tr>
					
			<?php
				}
			?>
			</table>
			</div>
			
			<br><br>
			
			<div class="llista">
			<h3>USUARIS ACTUALS</h3>
			<table>
				<tr id="cap">
					<td>USUARI</td>

				</tr>
			<?php
				$usuaris="/var/www/html/projectephp/inici/dirusuaris";
				$llista = scandir($usuaris);
				foreach($llista as $usuari){
	

			?>
				<tr>
					<td><?php echo $usuari; ?></td>


				</tr>
					
			<?php
				}
			?>
			</table>
			</div>
			
			<br><br>
		</body>
</html>
