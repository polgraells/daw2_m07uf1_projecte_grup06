<?php

	$id=rand(0,10000);
	$user=$_POST["usuari"];
	$paswd=$_POST["ctsnya"];
	$filename="/var/www/html/projectephp/inici/dirusuaris/".$user;	
		
	$fitxer=fopen($filename,"w") or die ("No s'ha pogut crear el fitxer");		
	fwrite($fitxer,$user);														
	fwrite($fitxer,":");
	fwrite($fitxer,$paswd);
	fwrite($fitxer,":");
	fwrite($fitxer,"\n");
	fclose($fitxer);															

	$general="/var/www/html/projectephp/inici/usuaris";
	$fp=fopen($general,"a") or die ("No s'ha pogut afegir al fitxer");		
	fwrite($fp,$user);														
	fwrite($fp,":");
	fwrite($fp,$paswd);
	fwrite($fp,":");
	fwrite($fp,"\n");
	fclose($fp);
	header('Location: http://localhost/projectephp/inici/inici.html');
?>


