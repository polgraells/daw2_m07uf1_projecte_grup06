<?php
	$fitxer_producte="/var/www/html/projectephp/inici/dirproductes/".$_POST['producte'];
	$id=$_POST["producte"];
	$seccio=$_POST["seccio"];
	$model=$_POST["model"];
	$preu=$_POST["preu"];
	
	$fp=fopen($fitxer_producte,"w") or die ("No s'ha pogut validar el producte");
	fwrite($fp,$id);
	fwrite($fp,"-");
	fwrite($fp,$seccio);
	fwrite($fp,"-");
	fwrite($fp,$model);
	fwrite($fp,"-");
	fwrite($fp,$preu);
	fwrite($fp,"€\n");
	fclose($fitxer);
	

	$general="/var/www/html/projectephp/inici/productes";
	$fo=fopen($general,"a") or die ("No s'ha pogut validar el producte");
	fwrite($fo,$id);
	fwrite($fo,"-");
	fwrite($fo,$seccio);
	fwrite($fo,"-");
	fwrite($fo,$model);
	fwrite($fo,"-");
	fwrite($fo,$preu);
	fwrite($fo,"€\n");
	fclose($fo);
	
	header('Location: http://localhost/projectephp/inici/productosadmin.php');
?>
