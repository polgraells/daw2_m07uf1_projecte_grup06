<?php
	echo "<b>AFEGINT DADES AL FINAL DEL FITXER</b><br>";
	$filename="/var/www/html/projectephp/inici/productosadmin.php".$_POST["nom"];
	$fitxer=fopen($filename,"a") or die ("No s'ha pogut obrir el fitxer 1");
	fwrite($fitxer,$_POST);
	fclose($fitxer);
	echo "S'ha afegit una nova linia de texte al fitxer".$_POST["nom"]."<br>";
?>

